package com.example.flashapp

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var isFlashOn = false

    private val CAMERA_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnToggleFlash = findViewById<Button>(R.id.btnToggleFlash)

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager

        try {
            cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(
                    android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)
                hasFlash == true
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }

        if (cameraId == null) {
            Toast.makeText(this, "No camera with flash found", Toast.LENGTH_SHORT).show()
            btnToggleFlash.isEnabled = false
            return
        }

        btnToggleFlash.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
            } else {
                toggleFlash(btnToggleFlash)
            }
        }
    }

    private fun toggleFlash(button: Button) {
        cameraId?.let { id ->
            try {
                isFlashOn = !isFlashOn
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    cameraManager.setTorchMode(id, isFlashOn)
                    button.text = if (isFlashOn) "Turn Off Flash" else "Turn On Flash"
                }
            } catch (e: CameraAccessException) {
                e.printStackTrace()
                Toast.makeText(this, "Error toggling flash", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                val btnToggleFlash = findViewById<Button>(R.id.btnToggleFlash)
                toggleFlash(btnToggleFlash)
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
